import { useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import { toCanvas } from 'html-to-image';
import { Pause, Play, X } from '@mynaui/icons-react';
import type { PreviewItem } from '../content';
import type { Rect } from './wave-model';
import { DistortionWave } from './DistortionWave';

export type OpenPreview = { item: PreviewItem; origin: Rect; start: Rect; trigger: HTMLButtonElement };

export function ProjectPreview({ selected, onClose, paused, onPause, reduced, surface, media, poster, view }: {
  selected: OpenPreview | null; onClose: () => void; paused: boolean; onPause: () => void;
  reduced: boolean; surface: RefObject<HTMLDivElement | null>; media: RefObject<HTMLVideoElement | null>;
  poster: RefObject<HTMLImageElement | null>; view: string;
}) {
  const dialog = useRef<HTMLDialogElement>(null), close = useRef<HTMLButtonElement>(null);
  const recording = useRef<HTMLVideoElement>(null);
  const snapshot = useRef<HTMLCanvasElement | null>(null), overlay = useRef<HTMLCanvasElement | null>(null);
  const [failed, setFailed] = useState(false);
  const [expanding, setExpanding] = useState(false);
  const [settled, setSettled] = useState(false);
  useEffect(() => {
    let stopped = false, generation = 0;
    const prepare = async () => {
      const token = ++generation;
      overlay.current = null;
      if (!surface.current) return;
      try {
        await document.fonts.ready;
        const result = await toCanvas(surface.current, { width: innerWidth, height: innerHeight, pixelRatio: 1, backgroundColor: 'transparent', style: { opacity: '1' }, filter: node => !(node instanceof Element && node.classList.contains('shape-physics')) });
        if (!stopped && token === generation) overlay.current = result;
      } catch { /* Entry stays usable when browser capture is unavailable. */ }
    };
    void prepare(); window.addEventListener('resize', prepare);
    return () => { stopped = true; generation++; window.removeEventListener('resize', prepare); };
  }, [view, surface]);
  useLayoutEffect(() => {
    const element = dialog.current;
    if (!element) return;
    if (!selected) { element.close(); return; }
    setSettled(false);
    const texture = document.createElement('canvas'); texture.width = innerWidth; texture.height = innerHeight;
    const ctx = texture.getContext('2d')!;
    const video = media.current, image = poster.current;
    const input = video && video.readyState >= 2 ? video : image;
    const iw = input instanceof HTMLVideoElement ? input.videoWidth : image?.naturalWidth ?? 0;
    const ih = input instanceof HTMLVideoElement ? input.videoHeight : image?.naturalHeight ?? 0;
    ctx.fillStyle = '#030408'; ctx.fillRect(0, 0, texture.width, texture.height);
    if (input && iw && ih) {
      const scale = Math.max(texture.width / iw, texture.height / ih);
      ctx.drawImage(input, (texture.width - iw * scale) / 2, (texture.height - ih * scale) / 2, iw * scale, ih * scale);
    }
    ctx.fillStyle = 'rgba(3,4,8,.68)'; ctx.fillRect(0, 0, texture.width, texture.height);
    if (overlay.current) ctx.drawImage(overlay.current, 0, 0);
    const dolls = surface.current?.querySelector<HTMLCanvasElement>('.shape-physics canvas');
    if (dolls) { const rect = dolls.getBoundingClientRect(); ctx.drawImage(dolls, rect.x, rect.y, rect.width, rect.height); }
    snapshot.current = texture;
    if (!element.open) element.showModal();
    setExpanding(true);
    const bounds = element.getBoundingClientRect();
    const start = selected.start;
    const left = Math.max(0, Math.min(bounds.width - start.w, start.x - bounds.x));
    const top = Math.max(0, Math.min(bounds.height - start.h, start.y - bounds.y));
    const clip = `inset(${top}px ${Math.max(0, bounds.width - left - start.w)}px ${Math.max(0, bounds.height - top - start.h)}px ${left}px round 22px)`;
    const animation = reduced ? null : element.animate([
      { clipPath: clip, opacity: .92 },
      { clipPath: 'inset(0px 0px 0px 0px round 24px)', opacity: 1 },
    ], { duration: 600, easing: 'cubic-bezier(.23,1,.32,1)' });
    if (animation) animation.onfinish = () => setExpanding(false);
    else setExpanding(false);
    close.current?.focus({ preventScroll: true });
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const resize = () => { animation?.cancel(); onClose(); };
    window.addEventListener('resize', resize);
    return () => { animation?.cancel(); window.removeEventListener('resize', resize); element.close(); document.body.style.overflow = previous; selected.trigger.focus({ preventScroll: true }); };
  }, [selected, media, poster]);
  useEffect(() => {
    setFailed(false);
  }, [selected?.item.id]);
  useEffect(() => {
    const video = recording.current;
    if (!video) return;
    const sync = () => { if (paused || reduced || document.hidden) video.pause(); else void video.play().catch(() => setFailed(true)); };
    sync(); document.addEventListener('visibilitychange', sync);
    return () => document.removeEventListener('visibilitychange', sync);
  }, [paused, reduced, selected?.item.id]);
  return <dialog ref={dialog} className={'project-window' + (settled ? ' is-settled' : '')} aria-label={selected ? selected.item.title + ' preview' : 'Project preview'} onCancel={onClose} onClick={event => { if (event.target === event.currentTarget) { const rect = event.currentTarget.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) onClose(); } }}>
    <div className="preview-content">
      {selected && <div className={'project-case' + (selected.item.preview || selected.item.image ? ' has-media' : '')}>
        {(selected.item.preview || selected.item.image) && <div className="case-media">{selected.item.preview && !failed ? <video key={selected.item.id} ref={recording} src={selected.item.preview} muted loop playsInline autoPlay={!paused && !reduced} controls preload="metadata" onError={() => setFailed(true)} aria-label={selected.item.title + ' recording'} /> : selected.item.image ? <img src={selected.item.image} width="1440" height="900" alt="AI video workspace showing prompt, reference asset and generation settings controls" /> : <p role="status">The recording could not load. Reload the page to try again.</p>}</div>}
        <article className="case-details"><h2>{selected.item.title}</h2><p>{selected.item.summary}</p><h3>Contribution</h3><p>{selected.item.contribution}</p><h3>Result & scope</h3><p>{selected.item.result}</p>{selected.item.link && <a className="glass-button case-link" href={selected.item.link.href} target="_blank" rel="noreferrer">{selected.item.link.label}</a>}</article>
      </div>}
    </div>
    <DistortionWave open={Boolean(selected)} source={selected?.origin ?? null} snapshot={snapshot} media={recording} paused={paused} reduced={reduced} onLiving={() => setSettled(true)} />
    <div className={'preview-controls' + (expanding ? ' is-expanding' : '')}><button className="preview-control" aria-label={paused ? 'Resume motion' : 'Pause motion'} aria-pressed={paused} onClick={onPause} hidden={reduced}>{paused ? <Play size={16} aria-hidden="true" /> : <Pause size={16} aria-hidden="true" />}</button><button ref={close} className="preview-control" aria-label="Close preview" onClick={onClose}><X size={18} aria-hidden="true" /></button></div>
  </dialog>;
}
