import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, type MotionValue } from 'motion/react';
import type { PreviewItem } from '../content';

export function MiniPreview({ item, x, y, width, paused, reduced }: {
  item: PreviewItem | null; x: MotionValue<number>; y: MotionValue<number>; width: number;
  paused: boolean; reduced: boolean;
}) {
  const video = useRef<HTMLVideoElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => { setFailed(false); }, [item?.id]);
  useEffect(() => {
    const element = video.current;
    if (!element) return;
    const sync = () => { if (paused || reduced || document.hidden) element.pause(); else void element.play().catch(() => setFailed(true)); };
    sync(); document.addEventListener('visibilitychange', sync);
    return () => document.removeEventListener('visibilitychange', sync);
  }, [item?.id, paused, reduced]);
  return <AnimatePresence>{item && <motion.div className="phone-follow" style={{ x, y, width }} initial={{ opacity: 0, scale: reduced ? 1 : .96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: reduced ? 1 : .98 }} transition={{ duration: reduced ? 0 : .18, ease: [.23, 1, .32, 1] }}><div className="phone-screen" role="img" aria-label={item.title + ' mini preview'}>{item.preview && !failed ? <video key={item.id} ref={video} src={item.preview} muted loop playsInline autoPlay={!paused && !reduced} onError={() => setFailed(true)} aria-hidden="true" /> : item.image ? <img src={item.image} width="1440" height="900" alt="" /> : <div className="mini-summary"><strong>{item.title}</strong><span>{item.summary}</span></div>}</div></motion.div>}</AnimatePresence>;
}
