import { useEffect, useRef, type RefObject } from 'react';
import { defaultStyle, duration, waveFront, rimLumps, smooth, PALETTES, type Front, type Rect } from './wave-model';
import { WaveRenderer } from './wave-renderer';

const STYLE = {
  ...defaultStyle('vertical'), palette: PALETTES.colorful,
  anticipation: .5, travel: 2.28, pull: 48, blur: 10, aberration: .22,
  rimFade: 1.4, hairlineLinger: 0, hairlineFade: 1.4,
  particleCount: 0, particleLife: 0, cornerRadius: 24,
};

// Libraries.dev's original field, lens and palette (Jakub Antalik, MIT).
// After release only the perimeter is drawn, leaving preview media live below.
export function DistortionWave({ open, source, snapshot, media, paused, reduced, onLiving }: {
  open: boolean; source: Rect | null; snapshot: RefObject<HTMLCanvasElement | null>;
  media: RefObject<HTMLVideoElement | null>;
  paused: boolean; reduced: boolean; onLiving: () => void;
}) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const renderer = useRef<WaveRenderer | null>(null);
  const wake = useRef<(() => void) | null>(null);
  const pause = useRef(paused); pause.current = paused;
  const living = useRef(onLiving); living.current = onLiving;
  useEffect(() => {
    if (!canvas.current) return;
    try { renderer.current = new WaveRenderer(canvas.current); } catch { return; }
    return () => { renderer.current?.dispose(); renderer.current = null; };
  }, []);
  useEffect(() => {
    const view = canvas.current, r = renderer.current;
    if (!open || !view || !r?.ok) return;
    const area = view.getBoundingClientRect(), width = area.width, height = area.height;
    const ratio = Math.min(1, 1100 / width, 900 / height);
    view.width = Math.max(1, Math.round(width * ratio));
    view.height = Math.max(1, Math.round(height * ratio));
    const texture = document.createElement('canvas');
    texture.width = view.width; texture.height = view.height;
    const ctx = texture.getContext('2d', { alpha: false });
    if (!ctx) return;
    ctx.fillStyle = '#191919'; ctx.fillRect(0, 0, texture.width, texture.height);
    const blank = document.createElement('canvas'); blank.width = view.width; blank.height = view.height;
    const fill = blank.getContext('2d')!;
    const drawPreview = () => {
      fill.fillStyle = '#191919'; fill.fillRect(0, 0, blank.width, blank.height);
      const video = media.current;
      if (!video || video.readyState < 2 || !video.videoWidth) return;
      const scale = Math.max(blank.width / video.videoWidth, blank.height / video.videoHeight);
      const w = video.videoWidth * scale, h = video.videoHeight * scale;
      fill.drawImage(video, (blank.width - w) / 2, (blank.height - h) / 2, w, h);
    };
    drawPreview();
    if (snapshot.current) ctx.drawImage(snapshot.current, area.x, area.y, width, height, 0, 0, texture.width, texture.height);
    r.setScreen(texture, width, height, STYLE.blur);
    r.setRevealed(blank);
    const origin = source ? { ...source, x: source.x - area.x, y: source.y - area.y } : { x: width / 2, y: height / 2, w: 46, h: 46 };
    const total = duration(STYLE);
    const idle: Front = {
      ...waveFront(1, origin, width, height, STYLE), energy: 0, gravity: 0, glow: 0,
      hold: 0, hasCleared: true, launched: true, rim: STYLE.rimStrength,
      clearRadius: -Math.max(width, height) * 2, hairClearRadius: -Math.max(width, height) * 2,
    };
    let raf = 0, previous = 0, elapsed = reduced ? total : 0, disposed = false, notified = false, videoTime = -1;
    let intervals = 0, late = 0, drawTotal = 0, frames = 0;
    const tick = (time: number) => {
      raf = 0;
      if (disposed) return;
      const delta = previous ? Math.min((time - previous) / 1000, .05) : 0;
      if (previous && time - previous > 25) late++;
      if (previous) intervals++;
      previous = time;
      if (!pause.current && !document.hidden && !reduced) elapsed += delta;
      const live = elapsed >= total;
      const drawStart = performance.now();
      const video = media.current;
      if (!live && video && video.readyState >= 2 && video.currentTime !== videoTime) { videoTime = video.currentTime; drawPreview(); r.updateRevealed(blank); }
      idle.time = total + (elapsed - total) * .28;
      const front = live ? idle : waveFront(elapsed / total, origin, width, height, STYLE);
      if (!live) {
        front.rim = STYLE.rimStrength * smooth(0, .1, front.flying / STYLE.travel);
      }
      if (live && !notified) { notified = true; living.current(); }
      r.render(front, STYLE, rimLumps(front.time, width, height, STYLE.cornerRadius, STYLE.rimPulse), null, live);
      view.dataset.wavePhase = live ? 'living' : elapsed < STYLE.anticipation ? 'catch' : 'release';
      if (import.meta.env.DEV) {
        drawTotal += performance.now() - drawStart; frames++;
        if (frames % 60 === 0) { view.dataset.waveFrames = String(frames); view.dataset.waveLateFrames = `${late}/${intervals}`; view.dataset.waveDrawMs = (drawTotal / frames).toFixed(2); }
      }
      if (!reduced && !pause.current && !document.hidden) raf = requestAnimationFrame(tick);
    };
    const resume = () => { if (!raf && !disposed) { previous = 0; raf = requestAnimationFrame(tick); } };
    wake.current = resume;
    document.addEventListener('visibilitychange', resume);
    raf = requestAnimationFrame(tick);
    return () => { disposed = true; cancelAnimationFrame(raf); r.clear(); wake.current = null; document.removeEventListener('visibilitychange', resume); };
  }, [open, source, snapshot, media, reduced]);
  useEffect(() => { wake.current?.(); }, [paused]);
  return <canvas ref={canvas} className="preview-wave" aria-hidden="true" />;
}
