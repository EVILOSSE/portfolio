import { useCallback, useEffect, useLayoutEffect, useRef, useState, type PointerEvent } from 'react';
import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from 'motion/react';
import { ArrowDown, ArrowUpRight, Pause, Play } from '@mynaui/icons-react';
import { profile, projects, skills, asset, type PreviewItem } from './content';
import { ProjectPreview, type OpenPreview } from './components/ProjectPreview';
import { ShapePhysics } from './components/shape-physics';
import { MiniPreview } from './components/MiniPreview';

type View = 'work' | 'skills' | 'contact';
const SPRING = { stiffness: 340, damping: 28, mass: .7 };

export default function App() {
  const reduced = useReducedMotion();
  const [entered, setEntered] = useState(false);
  const [view, setView] = useState<View>('work');
  const [preview, setPreview] = useState<OpenPreview | null>(null);
  const [mini, setMini] = useState<PreviewItem | null>(null);
  const miniMode = useRef<'pointer' | 'anchored'>('pointer');
  const pointerType = useRef('mouse');
  const [miniWidth, setMiniWidth] = useState(190);
  const phoneSize = useRef({ width: 190, height: 412 });
  const rawX = useMotionValue(0), rawY = useMotionValue(0);
  const x = useSpring(rawX, SPRING), y = useSpring(rawY, SPRING);
  const [paused, setPaused] = useState(false), [failed, setFailed] = useState(false);
  const [copy, setCopy] = useState<'idle' | 'copied' | 'error'>('idle');
  const video = useRef<HTMLVideoElement>(null), poster = useRef<HTMLImageElement>(null), main = useRef<HTMLElement>(null), surface = useRef<HTMLDivElement>(null);
  const introTrack = useRef<HTMLDivElement>(null), introStage = useRef<HTMLDivElement>(null);
  const introComplete = useRef(false), focusAfterEntry = useRef(false);
  const introProgress = useMotionValue(0);
  const windowClip = useTransform(introProgress, [0, 1], ['inset(13% 12% round 36px)', 'inset(0% 0% round 0px)']);
  const surfaceOpacity = useTransform(introProgress, [0, .55, 1], [0, 0, 1]);
  const shadeOpacity = useTransform(introProgress, [0, .35, 1], [0, 0, .68]);
  const cueOpacity = useTransform(introProgress, [0, .18], [1, 0]);
  const isEntered = entered;
  const finishIntro = useCallback(() => {
    if (introComplete.current) return;
    introComplete.current = true;
    introProgress.set(1);
    setEntered(true);
  }, [introProgress]);
  useLayoutEffect(() => {
    const previous = history.scrollRestoration;
    history.scrollRestoration = 'manual';
    window.scrollTo({ top: 0, behavior: 'instant' });
    return () => { history.scrollRestoration = previous; };
  }, []);
  useEffect(() => {
    if (entered) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      if (introComplete.current) return;
      const range = (introTrack.current?.offsetHeight ?? innerHeight) - (introStage.current?.clientHeight ?? innerHeight);
      const progress = Math.max(0, Math.min(1, scrollY / Math.max(1, range)));
      if (reduced) {
        if (scrollY > 4) finishIntro();
      } else {
        introProgress.set(progress);
        if (progress >= .998) finishIntro();
      }
    };
    const scroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    window.addEventListener('scroll', scroll, { passive: true });
    window.addEventListener('resize', scroll);
    return () => { cancelAnimationFrame(frame); window.removeEventListener('scroll', scroll); window.removeEventListener('resize', scroll); };
  }, [entered, reduced, finishIntro, introProgress]);
  useLayoutEffect(() => {
    if (!entered) return;
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (focusAfterEntry.current) { main.current?.focus({ preventScroll: true }); focusAfterEntry.current = false; }
  }, [entered]);
  useEffect(() => {
    const element = video.current;
    if (!element) return;
    const sync = () => { if (paused || reduced || document.hidden) element.pause(); else void element.play().catch(() => setFailed(true)); };
    sync(); document.addEventListener('visibilitychange', sync);
    return () => document.removeEventListener('visibilitychange', sync);
  }, [paused, reduced]);
  useEffect(() => {
    const measure = () => {
      const preferred = innerWidth <= 600 ? 160 : Math.min(220, Math.max(160, innerWidth * .15));
      const width = Math.min(preferred, Math.max(0, ((main.current?.clientHeight ?? innerHeight) - 116) * 390 / 844));
      phoneSize.current = { width, height: width * 844 / 390 }; setMiniWidth(width); setMini(null);
    };
    measure(); window.addEventListener('resize', measure);
    const dismiss = (event: KeyboardEvent) => { if (event.key === 'Escape') setMini(null); };
    window.addEventListener('keydown', dismiss);
    return () => { window.removeEventListener('resize', measure); window.removeEventListener('keydown', dismiss); };
  }, []);
  const positionMini = (clientX: number, clientY: number, jump = false) => {
    const { width, height } = phoneSize.current;
    const bottom = main.current?.clientHeight ?? innerHeight;
    const left = clientX + width + 32 < innerWidth ? clientX + 26 : clientX - width - 26;
    const top = Math.max(92, Math.min(bottom - height - 18, clientY - height * .45));
    if (jump || reduced) { x.jump(Math.max(18, left)); y.jump(top); }
    rawX.set(Math.max(18, left)); rawY.set(top);
  };
  const hoverMini = (item: PreviewItem, event: PointerEvent<HTMLButtonElement>) => {
    if (preview || phoneSize.current.width < 48 || event.pointerType !== 'mouse' || !matchMedia('(hover:hover)').matches) return;
    miniMode.current = 'pointer'; positionMini(event.clientX, event.clientY, !mini); setMini(item);
  };
  const anchorMini = (item: PreviewItem, element: HTMLButtonElement) => {
    if (preview || phoneSize.current.width < 48) return;
    miniMode.current = 'anchored'; const rect = element.getBoundingClientRect();
    positionMini(rect.right, rect.y + rect.height / 2, true); setMini(item);
  };
  const openPreview = (item: PreviewItem, trigger: HTMLButtonElement) => {
    const rect = trigger.getBoundingClientRect();
    const phone = document.querySelector('.phone-follow')?.getBoundingClientRect();
    const start = phone && mini?.id === item.id ? { x: phone.x, y: phone.y, w: phone.width, h: phone.height } : { x: rect.x, y: rect.y, w: rect.width, h: rect.height };
    setMini(null);
    setPreview({ item, trigger, start, origin: start });
  };
  const switchView = (next: View) => { setPreview(null); setMini(null); setView(next); setCopy('idle'); location.hash = next; };
  useEffect(() => {
    const sync = () => { const next = location.hash.slice(1); if (next === 'work' || next === 'skills' || next === 'contact') { setView(next); setPreview(null); setMini(null); } };
    sync(); window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  const enter = (keyboard: boolean) => {
    focusAfterEntry.current = keyboard;
    if (keyboard || reduced) { finishIntro(); return; }
    const range = (introTrack.current?.offsetHeight ?? innerHeight) - (introStage.current?.clientHeight ?? innerHeight);
    window.scrollTo({ top: range, behavior: 'smooth' });
  };
  const copyEmail = async () => { try { await navigator.clipboard.writeText(profile.email); setCopy('copied'); } catch { setCopy('error'); } };
  const items = view === 'work' ? projects : skills;
  return <div className={'intro-track' + (isEntered ? ' is-complete' : '')} ref={introTrack}><div className={'portfolio-app' + (isEntered ? ' entered' : '')} ref={introStage}>
    <motion.div className="space-window" style={{ clipPath: windowClip }} aria-hidden="true"><img ref={poster} className="space-poster" src={asset('media/space-poster.jpg')} width="1920" height="1080" alt="" fetchPriority="high" /><video ref={video} className={failed || reduced ? 'space-video is-hidden' : 'space-video'} src={reduced ? undefined : asset('media/space-loop.mp4')} poster={asset('media/space-poster.jpg')} muted loop playsInline autoPlay={!reduced} preload="auto" onError={() => setFailed(true)} /><motion.div className="space-shade" style={{ opacity: shadeOpacity }} /></motion.div>
    {!isEntered && <motion.button className="enter-button glass-button" style={{ opacity: cueOpacity }} aria-label="Scroll to enter portfolio" onClick={event => enter(event.detail === 0)}><ArrowDown size={22} aria-hidden="true" /></motion.button>}
    <motion.div ref={surface} className="portfolio-surface" style={{ opacity: surfaceOpacity }} inert={isEntered ? undefined : true}>
      <a href="#main-content" className="skip-link">Skip to portfolio</a>
      <nav className="top-nav" aria-label="Portfolio views">{([{ id: 'work', label: 'Projects' }, { id: 'skills', label: 'Skills' }, { id: 'contact', label: 'Contact' }] as const).map(tab => <button key={tab.id} className={view === tab.id ? 'view-button is-active' : 'view-button'} aria-current={view === tab.id ? 'page' : undefined} onClick={() => switchView(tab.id)}>{view === tab.id && <motion.span className="view-selection" layoutId="view-selection" transition={reduced ? { duration: 0 } : SPRING} />}<span>{tab.label}</span></button>)}</nav>
      <main className={'view-stage view-' + view} ref={main} id="main-content" tabIndex={-1}>
        <h1 className="sr-only">{profile.name} — {view === 'work' ? 'Projects' : view === 'skills' ? 'Skills' : 'Contact'}</h1>
        {view !== 'contact' ? <div className="title-menu" key={view} aria-label={view === 'work' ? 'Projects' : 'Skills'} onPointerLeave={() => { if (miniMode.current === 'pointer') setMini(null); }}>{items.map(item => <button key={item.id} className={'title-button' + (mini?.id === item.id ? ' is-active' : '')} onPointerDown={event => { pointerType.current = event.pointerType; }} onPointerEnter={event => hoverMini(item, event)} onPointerMove={event => { if (mini && miniMode.current === 'pointer' && !preview) positionMini(event.clientX, event.clientY); }} onFocus={event => { if (event.currentTarget.matches(':focus-visible')) anchorMini(item, event.currentTarget); }} onBlur={() => { if (miniMode.current === 'anchored') setMini(null); }} onClick={event => { if (event.detail > 0 && pointerType.current !== 'mouse' && mini?.id !== item.id) anchorMini(item, event.currentTarget); else openPreview(item, event.currentTarget); }} aria-label={'Preview ' + item.title} aria-haspopup="dialog">{'icon' in item && <img src={asset('icons/' + item.icon + '.svg')} width="27" height="27" alt="" />}<span>{item.title}</span><ArrowUpRight size={23} aria-hidden="true" /></button>)}</div> : <div className="contact-view"><a className="email-link" href={'mailto:' + profile.email}>{profile.email}<ArrowUpRight size={25} aria-hidden="true" /></a><button className="glass-button copy-button" onClick={copyEmail}>{copy === 'copied' ? 'Copied' : 'Copy email'}</button><p className="copy-status" role="status">{copy === 'error' ? 'Copy the address above manually, or select it to open your email app.' : copy === 'copied' ? 'Copied to your clipboard.' : ''}</p></div>}
      </main>
      <footer className="dolls-footer"><div className="footer-details"><div className="footer-identity"><span className="footer-name">{profile.name}</span><span>{profile.role}</span></div><div className="footer-contact"><span>{profile.email}</span>{profile.location && <span>{profile.location}</span>}</div></div><div className="footer-media-credit">Space footage: <a href="https://esahubble.org/videos/heic1509b/" target="_blank" rel="noreferrer">Zoom into Westerlund 2</a>. N. Risinger (Skysurvey.org), NASA, ESA, Digitized Sky Survey 2, the Hubble Heritage Team (STScI/AURA), A. Nota (ESA/STScI), and the Westerlund 2 Science Team. Excerpt reversed, looped, and compressed.</div><ShapePhysics count={22} size={50} background="transparent" paused={!isEntered || paused || Boolean(reduced)} aria-label="Interactive dolls. Drag to throw, click or press Enter to add, R to replay." /></footer>
    </motion.div>
    <MiniPreview item={preview ? null : mini} x={x} y={y} width={miniWidth} paused={paused} reduced={Boolean(reduced)} />
    <button className={'motion-control' + (!isEntered ? ' initially-hidden' : '')} aria-label={paused ? 'Resume motion' : 'Pause motion'} aria-pressed={paused} hidden={Boolean(reduced)} onClick={() => { setFailed(false); setPaused(!paused); }}>{paused ? <Play size={16} aria-hidden="true" /> : <Pause size={16} aria-hidden="true" />}</button>
    <ProjectPreview selected={preview} onClose={() => setPreview(null)} paused={paused} onPause={() => setPaused(!paused)} reduced={Boolean(reduced)} surface={surface} media={video} poster={poster} view={view} />
  </div></div>;
}

