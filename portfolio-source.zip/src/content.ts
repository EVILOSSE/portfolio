export const profile = {
  name: 'Abd El Moumen Zakaria',
  email: 'founder@goldensticker.xyz',
  role: 'React & TypeScript · AI-assisted development',
  location: 'Algeria · UTC+1',
};

export const asset = (path: string) => import.meta.env.BASE_URL + path.split('/').pop();
export type PreviewItem = {
  id: string; title: string; preview?: string; image?: string;
  summary: string; contribution: string; result: string;
  link?: { label: string; href: string };
};
export const projects: PreviewItem[] = [
  {
    id: 'hawa-shop', title: 'Hawa Shop', preview: asset('media/hawa-shop.mp4'),
    summary: 'A French-language electronics storefront prototype with a catalogue, product pages, comparison and basket interfaces.',
    contribution: 'I directed the shop brief, visual direction and AI-assisted implementation, and supplied this walkthrough of the interface.',
    result: 'The recording shows catalogue browsing and product detail views. This is a design prototype; live orders, payments and a production database are not demonstrated.',
  },
  {
    id: 'video-workspace', title: 'AI Video Workspace', image: asset('media/video-workspace.jpg'),
    summary: 'A local workspace for a video-generation API: prompts, image/video/audio references, settings, task status and downloads in one place.',
    contribution: 'I defined the workflow and interface requirements and directed an AI-assisted implementation of the browser UI and Node.js proxy.',
    result: 'Four automated tests pass against a local test relay, covering payload validation, task status, streaming, history persistence and secret-file protection. A paid generation is not part of this public sample.',
    link: { label: 'View source & tests', href: 'https://github.com/EVILOSSE/portfolio/blob/main/VIDEO-WORKSPACE.md' },
  },
  {
    id: 'website-check', title: 'Website Check',
    summary: 'A dependency-free Python utility that checks saved HTML before a website repair and produces Markdown or JSON findings.',
    contribution: 'Prepared through an AI-assisted workflow as an original code sample, with explicit rules, reproducible tests and a documented scope.',
    result: 'Checks include duplicate IDs, missing image alternatives, unlabelled controls and missing local assets. It scans saved source; it does not certify rendered accessibility or live commerce.',
    link: { label: 'View source & tests', href: 'https://github.com/EVILOSSE/portfolio/blob/main/WEBSITE-CHECK.md' },
  },
];
export const skills: (PreviewItem & { icon: string })[] = [
  { id: 'react', title: 'React', icon: 'react', summary: 'Interfaces, state and reusable components.', contribution: 'My project work includes admin panels, order systems, management interfaces and this portfolio. I use AI-assisted implementation.', result: 'Explore the projects for concrete samples and their scope.' },
  { id: 'typescript', title: 'TypeScript', icon: 'typescript', summary: 'Typed UI data and component contracts.', contribution: 'This portfolio uses typed project content, React components and explicit interaction state.', result: 'The source is available with the portfolio.', link: { label: 'View portfolio source', href: 'https://github.com/EVILOSSE/portfolio/blob/main/README.md' } },
];
