# Approved portfolio direction

## Composition

Every page load begins with the space video inside an inset rounded window on white and a small down-arrow cue. Hash URLs select the eventual Projects, Skills, or Contact view without bypassing this arrival. A native 70svh scroll runway expands the window, darkens the footage, and reveals the portfolio. Scrolling back reverses it until completion. On completion the reveal latches, the extra runway collapses, and the portfolio remains a single-screen interface. Keyboard activation of the cue enters immediately with focus moved to main content. There is no oversized identity hero or sequence of marketing sections.

The compact top bar uses the pause control's translucent material: `rgba(0,0,0,.3)`, `blur(12px)`, rounded geometry, and no extra shadow. A rounded selected segment identifies Projects, Skills, or Contact. Project and skill titles sit at the left edge of the content area. The layout uses the available width without a narrow centered wrapper. Short viewports may scroll inside the main content region to keep controls reachable.

White and black provide the main contrast. The vivid nebula colors come from real space footage. Manrope supplies the strong, tightly tracked title typography and smaller control labels.

## Preview

The mini and large preview serve separate interactions. The mini is a plain white rounded rectangle with a `390 / 844` aspect ratio. It has no phone bezel, outline, notch, home indicator, or caption. Hover places it beside the cursor and springs follow pointer movement. Keyboard focus anchors it beside the title. A first touch tap anchors it; a second tap opens the large preview.

The large preview is an almost-fullscreen inset rounded window with a `#191919` blank surface. Click, Enter, Space, or the second touch tap opens it as a native modal dialog. It expands from the mini's position through a rounded clip while Libraries.dev's original colorful wave catches and bends a snapshot of the visible portfolio. The wave releases into the preview and leaves color along each edge as the front reaches it. A gently living perimeter remains after release, while the content below it stays available for future recordings. Close and pause controls sit at the upper right. Escape and backdrop clicks close the dialog; focus returns to the title.

Preview recordings are optional MP4 files configured in `src/content.ts`. Missing recordings intentionally leave both preview surfaces empty. The previous generated product mockups are removed. The page capture is prepared separately from the opening interaction, then combined with the visible media and doll canvas for the transition. Recording frames can feed the wave's revealed side during opening; the live recording remains below the perimeter afterward.

## Footer

The dolls have a separate, taller white footer. Outside rounded corner cutouts make the video appear to sit above this surface. Name, React/TypeScript role, work email, and media credit live behind the objects. Location is omitted until supplied. The colorful shapes retain the ReactDrops palette and white faces, with drag, throw, click-to-add, and keyboard add/replay interaction.

The footer is a real layer in the composition, rather than shapes floating directly over the space video. No decorative logo, availability badge, signature, invented achievement statistics, or unrelated action rows are included.

## Motion contract

- Arrival: native scrolling drives the rounded-window expansion and interface reveal, reversibly until completion. The completed state latches before the runway collapses. The down-arrow cue offers an equivalent entry action. There is no intro wave.
- View selection: state changes immediately; the local selected segment moves with a spring.
- Mini preview: hover supplies immediate spatial feedback, with position animated through Motion values. Keyboard focus and touch receive an anchored equivalent. Pointer exit, Escape, and view changes dismiss it.
- Large preview opening: title activation expands the rounded clip from the mini and starts the wave's catch and release together. The wave bends the portfolio snapshot before revealing the content. Closing interrupts the transition immediately.
- Large preview perimeter: color grows behind the traveling wave as it reaches each edge, then the original colorful palette continues gently around the rounded perimeter. Pause freezes the current motion; reduced motion keeps a static perimeter. Optional recordings remain live below the perimeter.
- Dolls: direct drag tracks the input; release transfers movement into the physics world. Transparent regions are cleared before repainting.
- Background: silent looping video; it pauses when the document is hidden or motion is paused.
- Reduced motion: retain the rounded poster intro, then enter immediately after a small scroll or cue activation. Mini positioning is immediate; the large preview opens immediately with a static colorful perimeter. No wave opening, automatic doll simulation, or preview playback. Manual actions remain available.

Visible keyboard focus remains; mouse clicks do not add a focus outline. Controls use semantic buttons or links with accessible names. A visually hidden heading preserves the portfolio hierarchy without adding visible copy.

## Content and sources

All current identity and project titles are editable placeholders. Skills use fetched Simple Icons SVGs; interface glyphs use MynaUI. Content is stored in `src/content.ts`; media belongs in `public/media/`.

Space source: [Zoom into Westerlund 2](https://esahubble.org/videos/heic1509b/). Credit: N. Risinger (Skysurvey.org), NASA, ESA, Digitized Sky Survey 2, the Hubble Heritage Team (STScI/AURA), A. Nota (ESA/STScI), and the Westerlund 2 Science Team. The excerpt was reversed, looped, resized, and compressed. Usage terms: [ESA/Hubble copyright](https://esahubble.org/copyright/).

Shapes: [ReactDrops Shape Physics](https://reactdrops.dev/r/shape-physics.json). Wave source: [Libraries.dev Waves](https://libraries.dev/waves), Jakub Antalik, MIT; notice retained in `docs/WAVES-LICENSE.txt`. Font: Manrope through Fontsource.

Taste Frontend is the primary design workflow within the user's supplied references and explicit decisions. Current Vercel Web Interface Guidelines are used for the implementation review. Rendered and runtime validation evidence is recorded separately by the main task, not asserted here.

