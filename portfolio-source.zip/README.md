# Space portfolio

A React, TypeScript, Vite, Tailwind CSS, and Motion portfolio for Abd El Moumen Zakaria. Work email: founder@goldensticker.xyz. Algeria, UTC+1. The project case studies distinguish prototypes and test evidence from live production results. Development is AI-assisted.

## Run locally

From this directory:

```powershell
npm install
npm run dev
```

Open [http://localhost:4190](http://localhost:4190). The development server binds to `127.0.0.1` on port `4190`.

```powershell
npm run build
npm run preview
```

`build` runs TypeScript checks and creates `dist/`. `preview` serves that build on the same port, so stop the development server first.

## Replace the content

Edit `src/content.ts`:

- `profile`: name, email address, role, and location.
- `projects`: stable IDs and project titles.
- `skills`: stable IDs, titles, and an icon filename from `public/icons/`, without `.svg`.
- Optional `preview`: a public URL for a project or skill recording.

For example, put `my-project.mp4` in `public/media/`, then set:

```ts
{ id: 'my-project', title: 'My project', preview: '/media/my-project.mp4' }
```

There are two previews. The mini preview is a plain rounded portrait rectangle with a `390 / 844` aspect ratio and a white surface. The large preview is an almost-fullscreen inset window with rounded corners and a `#191919` surface. Optional recordings are silent and looping, and fill each shape. Omit `preview` to leave both empty until real content is added. The earlier Orbit, Forma, and Echo mockup components, capture route, and generated screenshots have been removed.

Hover a project or skill title to show the mini preview beside the cursor; it follows through Motion values and springs. Keyboard focus gives an anchored mini. On touch, the first tap shows the mini and the second opens the large preview. Click a title, or activate it with Enter or Space, to open the large preview from the mini's position.

The large window expands while the opening wave catches and bends a snapshot of the visible portfolio. The wave releases into the preview and grows the original colorful perimeter as it reaches each edge. The perimeter remains gently moving after release. Close the dialog with its close button, Escape, or the backdrop. Focus returns to the title. The view is reflected in `#work`, `#skills`, or `#contact`.

## Structure

- `src/App.tsx`: arrival, top navigation, title menus, preview behavior, contact, and footer composition.
- `src/index.css`: layout, typography, materials, rounded geometry, and responsive rules.
- `src/components/shape-physics.tsx` and `solid-*`: the interactive dolls.
- `src/components/MiniPreview.tsx`: cursor-following and anchored portrait preview.
- `src/components/ProjectPreview.tsx`: preview dialog, recording playback, and cached page capture.
- `src/components/DistortionWave.tsx`, `wave-model.ts`, and `wave-renderer.ts`: Libraries.dev wave integration.
- `public/media/space-loop.mp4` and `space-poster.jpg`: the running space background and still fallback.

Every load starts with the rounded space window, including URLs ending in #work, #skills, or #contact; the hash selects the eventual view and does not bypass the intro. Native scrolling scrubs the reveal over a 70svh runway. Scroll back to reverse it before completion. At completion the intro latches, removes the extra runway, and returns the page to the single-screen portfolio. The down-arrow cue can scroll through entry; keyboard activation enters immediately and moves focus to the main content. The intro has no wave effect; Libraries.dev Waves belongs to the preview opening and perimeter.

The motion control pauses the background, preview wave and perimeter, recording playback, and doll simulation. A pause control is also available inside the large preview dialog. Reduced-motion preferences show the same rounded intro using the space poster, then enter immediately after a small scroll or cue activation. The mini moves immediately, and the large preview opens immediately with a static colorful perimeter. Automatic dolls stay static and preview playback stops while manual interaction remains available. The main area can scroll within its own region on short viewports.

## Sources and credits

Space footage: [Zoom into Westerlund 2](https://esahubble.org/videos/heic1509b/).

N. Risinger (Skysurvey.org), NASA, ESA, Digitized Sky Survey 2, the Hubble Heritage Team (STScI/AURA), A. Nota (ESA/STScI), and the Westerlund 2 Science Team. The excerpt has been reversed, looped, resized, and compressed. See [ESA/Hubble usage conditions](https://esahubble.org/copyright/).

- Shape Physics: [ReactDrops registry](https://reactdrops.dev/r/shape-physics.json). The original palette and white faces are retained. The local renderer clears transparent canvas regions before repainting to prevent accumulated trails.
- Distortion Waves: [Libraries.dev](https://libraries.dev/waves), by Jakub Antalik. MIT notice is retained in `docs/WAVES-LICENSE.txt`.
- Skill marks: [Simple Icons](https://simpleicons.org/).
- Interface icons: [MynaUI](https://mynaui.com/icons).
- Font: Manrope, loaded locally through Fontsource.

Validation results are recorded separately by the main task; this README makes no performance or browser-test claims.

