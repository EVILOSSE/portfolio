# Saved HTML diagnostic report

These checks inspect saved source. They do not establish live behaviour, visual quality or accessibility conformance.

## 404.html

Elements: 41. Findings for review: 0.

No findings from the implemented static checks.

## account/index.html

Elements: 262. Findings for review: 0.

No findings from the implemented static checks.

## account/orders/index.html

Elements: 304. Findings for review: 0.

No findings from the implemented static checks.

## ar/account/index.html

Elements: 262. Findings for review: 0.

No findings from the implemented static checks.

## ar/account/orders/index.html

Elements: 304. Findings for review: 0.

No findings from the implemented static checks.

## ar/cart/index.html

Elements: 180. Findings for review: 0.

No findings from the implemented static checks.

## ar/catalogue/index.html

Elements: 401. Findings for review: 0.

No findings from the implemented static checks.

## ar/checkout/index.html

Elements: 180. Findings for review: 0.

No findings from the implemented static checks.

## ar/compare/index.html

Elements: 182. Findings for review: 0.

No findings from the implemented static checks.

## ar/contact/index.html

Elements: 221. Findings for review: 0.

No findings from the implemented static checks.

## ar/enquiry/index.html

Elements: 169. Findings for review: 0.

No findings from the implemented static checks.

## ar/forgot-password/index.html

Elements: 54. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/acheter-un-ordinateur-occasion/index.html

Elements: 287. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/choisir-pc-gaming/index.html

Elements: 291. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/index.html

Elements: 262. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/ipad-ou-macbook/index.html

Elements: 276. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/macbook-mdm/index.html

Elements: 279. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/memoire-stockage/index.html

Elements: 288. Findings for review: 0.

No findings from the implemented static checks.

## ar/guides/preparer-livraison/index.html

Elements: 281. Findings for review: 0.

No findings from the implemented static checks.

## ar/index.html

Elements: 418. Findings for review: 0.

No findings from the implemented static checks.

## ar/login/index.html

Elements: 71. Findings for review: 0.

No findings from the implemented static checks.

## ar/privacy/index.html

Elements: 188. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/asus-tuf/index.html

Elements: 327. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/dell-5570/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/ipad-m4/index.html

Elements: 333. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/macbook-m4/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/macbook-max/index.html

Elements: 333. Findings for review: 0.

No findings from the implemented static checks.

## ar/products/msi-3060/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## ar/register/index.html

Elements: 73. Findings for review: 0.

No findings from the implemented static checks.

## ar/saved/index.html

Elements: 225. Findings for review: 0.

No findings from the implemented static checks.

## ar/sources/index.html

Elements: 274. Findings for review: 0.

No findings from the implemented static checks.

## cart/index.html

Elements: 180. Findings for review: 0.

No findings from the implemented static checks.

## catalogue/index.html

Elements: 401. Findings for review: 0.

No findings from the implemented static checks.

## checkout/index.html

Elements: 180. Findings for review: 0.

No findings from the implemented static checks.

## compare/index.html

Elements: 182. Findings for review: 0.

No findings from the implemented static checks.

## contact/index.html

Elements: 221. Findings for review: 0.

No findings from the implemented static checks.

## enquiry/index.html

Elements: 169. Findings for review: 0.

No findings from the implemented static checks.

## forgot-password/index.html

Elements: 54. Findings for review: 0.

No findings from the implemented static checks.

## guides/acheter-un-ordinateur-occasion/index.html

Elements: 287. Findings for review: 0.

No findings from the implemented static checks.

## guides/choisir-pc-gaming/index.html

Elements: 291. Findings for review: 0.

No findings from the implemented static checks.

## guides/index.html

Elements: 262. Findings for review: 0.

No findings from the implemented static checks.

## guides/ipad-ou-macbook/index.html

Elements: 276. Findings for review: 0.

No findings from the implemented static checks.

## guides/macbook-mdm/index.html

Elements: 279. Findings for review: 0.

No findings from the implemented static checks.

## guides/memoire-stockage/index.html

Elements: 288. Findings for review: 0.

No findings from the implemented static checks.

## guides/preparer-livraison/index.html

Elements: 281. Findings for review: 0.

No findings from the implemented static checks.

## index.html

Elements: 418. Findings for review: 0.

No findings from the implemented static checks.

## login/index.html

Elements: 71. Findings for review: 0.

No findings from the implemented static checks.

## privacy/index.html

Elements: 188. Findings for review: 0.

No findings from the implemented static checks.

## products/asus-tuf/index.html

Elements: 327. Findings for review: 0.

No findings from the implemented static checks.

## products/dell-5570/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## products/ipad-m4/index.html

Elements: 333. Findings for review: 0.

No findings from the implemented static checks.

## products/macbook-m4/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## products/macbook-max/index.html

Elements: 333. Findings for review: 0.

No findings from the implemented static checks.

## products/msi-3060/index.html

Elements: 330. Findings for review: 0.

No findings from the implemented static checks.

## record/index.html

Elements: 20. Findings for review: 0.

No findings from the implemented static checks.

## register/index.html

Elements: 73. Findings for review: 0.

No findings from the implemented static checks.

## saved/index.html

Elements: 225. Findings for review: 0.

No findings from the implemented static checks.

## sources/index.html

Elements: 274. Findings for review: 0.

No findings from the implemented static checks.

## Limits

- Static saved-HTML inspection only; JavaScript was not executed.
- Findings require contextual review; zero findings is not accessibility conformance.
- No visual, keyboard, screen-reader, network, performance, or payment-flow verification.
- No CSS background, srcset, script-generated resource, or external URL validation.
