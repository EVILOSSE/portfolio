# Website Check

A small original work sample for inspecting saved HTML before a website repair. Python 3.10+ is sufficient; there are no package dependencies, browser installs, credentials, paid APIs or outbound requests.

Run:

```text
python website_check.py path/to/site --site-root path/to/site --output report.md
python website_check.py path/to/page.html --format json
python -m unittest -v test_website_check.py
```

The optional site root enables resource-file presence checks. Inputs outside that root are rejected. The tool reads source, writes only the requested report, and does not modify the inspected website.

Checks cover document language/title/viewport, restrictive zoom, duplicate IDs, missing image alternatives, potentially unnamed controls, potentially unlabelled fields, and missing local resource files. `--fail-on-error` returns 1 for duplicate IDs or missing resource files; other items require review.

Saved source cannot establish the rendered accessible name or DOM after JavaScript runs. CSS visibility, CSS backgrounds, srcset references, browser layout, screen-reader behaviour, keyboard navigation, performance, SEO outcomes and payment flows are not verified. Relative asset checks are skipped when a base element is present. An empty report is not certification or evidence that a site has no bugs.

`sample-report.md` is an actual run against 58 saved HTML pages from a local design project. `sample-report.json` contains the same source-scan findings. The implemented static rules returned zero findings; that is a bounded source-scan result, not evidence of flawless accessibility or a functioning commerce system. File labels are relative to the project build root, and the report contains no account, password, buyer or payment information. The project was not changed. Check `validation.txt` for the actual test output and invocation details.

Prepared as an original code sample, not sold, published or submitted to a paid client. Copyright 2026 Nyxeo. Use, modification and redistribution are permitted under the included MIT license.
