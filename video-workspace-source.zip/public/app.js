const $ = id => document.getElementById(id);
const defaults = { prompt: '', duration: 5, resolution: '720p', ratio: '16:9', seed: -1, audio: true, cameraFixed: false, negativePrompt: '', extra: '{}' };
const storageKey = 'seedance:settings:v1';
const active = new Set(['queued', 'pending', 'in_progress', 'processing', 'running', 'submitted', 'unknown']);
let videos = [];
let assets = [];
let readingAssets = false;
let busy = false;
let polling = false;
let timer;

async function api(route, options = {}) {
  const response = await fetch(route, { ...options, headers: { 'Content-Type': 'application/json', ...options.headers } });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
  return data;
}

function settings() {
  return {
    prompt: $('prompt').value, duration: Number($('duration').value), resolution: $('resolution').value,
    ratio: $('ratio').value, seed: $('seed').value, audio: $('audio').checked,
    cameraFixed: $('camera-fixed').checked, negativePrompt: $('negative-prompt').value, extra: $('extra').value,
  };
}

function applySettings(value) {
  const next = { ...defaults, ...value };
  for (const field of ['prompt', 'duration', 'resolution', 'ratio', 'seed', 'extra']) $(field).value = next[field];
  $('negative-prompt').value = next.negativePrompt;
  $('audio').checked = next.audio;
  $('camera-fixed').checked = next.cameraFixed;
  updateForm();
}

function updateForm() {
  const length = $('prompt').value.length;
  $('prompt-count').textContent = `${new Intl.NumberFormat().format(length)} / 2,500`;
  $('prompt-count').classList.toggle('error-text', length > 2500);
  $('prompt').setAttribute('aria-invalid', String(length > 2500));
  showError('prompt-error', length > 2500 ? `Remove ${new Intl.NumberFormat().format(length - 2500)} characters. The relay allows 2,500.` : '');
  $('duration-minus').disabled = Number($('duration').value) <= 2;
  $('duration-plus').disabled = Number($('duration').value) >= 30;
  try { localStorage.setItem(storageKey, JSON.stringify(settings())); } catch {}
}

function showError(id, message) {
  $(id).textContent = message;
  $(id).hidden = !message;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function icon(name) {
  const node = element('span', `icon ${name}`);
  node.setAttribute('aria-hidden', 'true');
  return node;
}

function iconButton(name, label, action) {
  const button = element('button', 'icon-button');
  button.type = 'button';
  button.title = label;
  button.setAttribute('aria-label', label);
  button.append(icon(name));
  button.addEventListener('click', action);
  return button;
}

const statusLabels = { queued: 'Queued', in_progress: 'Generating…', completed: 'Ready', failed: 'Failed', cancelled: 'Cancelled', unknown: 'Waiting for relay…' };

function createCard(video) {
  const card = element('article', 'video-card');
  card.dataset.id = video.id;
  const media = element('div', 'video-media');
  const info = element('div', 'video-info');
  const prompt = element('p', 'video-prompt', video.prompt || 'Video generation');
  prompt.title = video.prompt;
  const meta = element('div', 'video-meta');
  const s = video.settings || {};
  for (const value of [`${s.duration ?? '?'}s`, s.resolution, s.ratio, s.audio ? 'Audio on' : 'Audio off']) if (value) meta.append(element('span', '', value));
  const date = element('time', '', new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(video.createdAt)));
  date.dateTime = video.createdAt;
  meta.append(date);
  const actions = element('div', 'video-actions');
  const status = element('span', 'status');
  const buttons = element('div');
  buttons.append(iconButton('reuse', 'Reuse prompt and settings', () => {
    applySettings({ ...video.settings, prompt: video.prompt });
    showError('form-error', '');
    $('prompt').focus();
    $('live-status').textContent = 'Prompt and settings copied to the form.';
  }));
  const download = element('a', 'icon-button');
  download.href = `/api/videos/${encodeURIComponent(video.id)}/content?download=1`;
  download.setAttribute('aria-label', 'Download video');
  download.title = 'Download video';
  download.append(icon('download'));
  buttons.append(download);
  actions.append(status, buttons);
  const error = element('p', 'video-error');
  info.append(prompt, meta, actions, error);
  card.append(media, info);
  return card;
}

function updateCard(card, video) {
  const media = card.querySelector('.video-media');
  const status = card.querySelector('.status');
  status.className = `status ${video.status}`;
  status.textContent = statusLabels[video.status] || video.status;
  const error = card.querySelector('.video-error');
  error.textContent = video.error || video.pollError || '';
  error.hidden = !error.textContent;
  card.querySelector('a').hidden = video.status !== 'completed';
  if (media.dataset.status === video.status) {
    const fill = media.querySelector('.progress > span');
    if (fill) fill.style.width = `${video.progress}%`;
    const progressText = media.querySelector('.progress-label');
    if (progressText) progressText.textContent = video.progress > 0 ? `${video.progress}%` : 'Waiting for the relay';
    return;
  }
  media.dataset.status = video.status;
  media.replaceChildren();
  if (video.status === 'completed') {
    const preview = element('div', 'video-placeholder');
    const play = element('button', 'video-play', 'Play video');
    play.type = 'button';
    play.addEventListener('click', () => {
      const player = document.createElement('video');
      player.controls = true;
      player.playsInline = true;
      player.preload = 'metadata';
      player.setAttribute('aria-label', video.prompt || 'Generated video');
      player.src = `/api/videos/${encodeURIComponent(video.id)}/content`;
      let fallback = false;
      player.addEventListener('error', () => {
        if (video.url && !fallback) { fallback = true; player.src = video.url; player.load(); return; }
        error.textContent = 'Could not load the video. Try Download or check your relay dashboard.';
        error.hidden = false;
      });
      media.replaceChildren(player);
      player.play().catch(() => {});
    });
    preview.append(icon('film'), play);
    media.append(preview);
  } else {
    const placeholder = element('div', 'video-placeholder');
    placeholder.append(icon('film'), element('strong', '', video.status === 'failed' ? 'Generation failed' : (statusLabels[video.status] || video.status)));
    if (active.has(video.status)) {
      const track = element('div', 'progress');
      track.append(element('span'));
      track.firstChild.style.width = `${video.progress}%`;
      placeholder.append(track, element('span', 'muted progress-label', video.progress > 0 ? `${video.progress}%` : 'Waiting for the relay'));
    }
    media.append(placeholder);
  }
}

function renderVideos() {
  $('empty').hidden = videos.length > 0;
  $('video-count').hidden = videos.length === 0;
  $('video-count').textContent = new Intl.NumberFormat().format(videos.length);
  const existing = new Map([...$('video-list').children].map(card => [card.dataset.id, card]));
  for (const [index, video] of videos.entries()) {
    const card = existing.get(video.id) || createCard(video);
    updateCard(card, video);
    if (!card.parentNode) $('video-list').insertBefore(card, $('video-list').children[index] || null);
  }
}

async function loadHistory() {
  try { videos = await api('/api/videos'); renderVideos(); showError('history-error', ''); }
  catch (error) { showError('history-error', `${error.message} Refresh to try again.`); }
}

function schedulePoll() {
  clearTimeout(timer);
  if (videos.some(v => active.has(v.status))) timer = setTimeout(pollVideos, document.hidden ? 20000 : 5000);
}

async function pollVideos() {
  if (polling) return;
  polling = true;
  const pending = videos.filter(v => active.has(v.status));
  await Promise.all(pending.map(async video => {
    try {
      const next = await api(`/api/videos/${encodeURIComponent(video.id)}`);
      Object.assign(video, next, { pollError: '' });
      if (!active.has(next.status)) $('live-status').textContent = next.status === 'completed' ? 'Your video is ready.' : 'Video generation failed. Check the error on your video.';
    } catch (error) { video.pollError = `${error.message} Status checks will retry automatically.`; }
  }));
  renderVideos();
  polling = false;
  schedulePoll();
}

async function checkConnection() {
  $('connection').disabled = true;
  $('connection-label').textContent = 'Connecting…';
  try {
    const result = await api('/api/connection');
    $('connection').className = `connection ${result.available ? 'connected' : 'failed'}`;
    $('connection-label').textContent = result.available ? 'Relay connected' : 'Model unavailable';
    $('connection').title = result.available ? 'Relay connected · Click to recheck' : 'The relay did not list seedance-2.5-turbo for this key. Click to recheck.';
  } catch (error) {
    $('connection').className = 'connection failed';
    $('connection-label').textContent = 'Connection error';
    $('connection').title = error.message;
    showError('form-error', `${error.message} Click the connection status to retry.`);
  } finally { $('connection').disabled = false; }
}

function renderAssets() {
  $('asset-list').replaceChildren();
  for (const asset of assets) {
    const row = element('div', 'asset-row');
    let preview;
    if (asset.type === 'image') {
      preview = document.createElement('img');
      preview.src = asset.preview;
      preview.alt = asset.name;
      preview.width = 52;
      preview.height = 52;
    } else if (asset.type === 'video') {
      preview = document.createElement('video');
      preview.src = asset.preview;
      preview.controls = true;
      preview.preload = 'metadata';
      preview.setAttribute('aria-label', asset.name);
    } else {
      preview = document.createElement('audio');
      preview.src = asset.preview;
      preview.controls = true;
      preview.preload = 'metadata';
      preview.setAttribute('aria-label', asset.name);
    }
    preview.className = `asset-preview ${asset.type}`;
    const info = element('div', 'asset-info');
    info.append(element('span', 'asset-name', asset.name), element('span', 'muted', `${asset.type} · ${new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(asset.size / 1024 / 1024)} MB`));
    if (asset.type === 'image') {
      const role = element('select', 'asset-role');
      role.setAttribute('aria-label', `Role for ${asset.name}`);
      for (const [value, label] of [['reference', 'Reference image'], ['first_frame', 'First frame'], ['last_frame', 'Last frame']]) { const option = element('option', '', label); option.value = value; role.append(option); }
      role.value = asset.role;
      role.addEventListener('change', () => { asset.role = role.value; });
      info.append(role);
    }
    const remove = iconButton('close', `Remove ${asset.name}`, () => {
      URL.revokeObjectURL(asset.preview);
      assets = assets.filter(value => value !== asset);
      renderAssets();
      $('asset-files').focus();
    });
    row.append(preview, info, remove);
    $('asset-list').append(row);
  }
  $('asset-count').hidden = assets.length === 0;
  $('asset-count').textContent = `${assets.length} ${assets.length === 1 ? 'asset' : 'assets'} · ${new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(assets.reduce((sum, a) => sum + a.size, 0) / 1024 / 1024)} / 40 MB`;
}

async function addAssets(files) {
  if (readingAssets) return;
  readingAssets = true;
  $('asset-drop').classList.add('reading');
  $('generate').disabled = true;
  showError('asset-error', '');
  const errors = [];
  const fallbackTypes = { mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp' };
  try {
    for (const file of files) {
      if (assets.some(a => a.name === file.name && a.size === file.size)) continue;
      const mime = file.type || fallbackTypes[file.name.split('.').pop().toLowerCase()];
      const type = mime?.split('/')[0];
      const supported = { image: ['image/png', 'image/jpeg', 'image/webp'], video: ['video/mp4', 'video/webm', 'video/quicktime'], audio: ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/ogg', 'audio/mp4', 'audio/aac', 'audio/webm', 'audio/flac', 'audio/x-flac'] };
      if (!supported[type]?.includes(mime)) { errors.push(`${file.name}: unsupported file format.`); continue; }
      if (assets.length >= 15) { errors.push('Attach up to 15 assets.'); break; }
      if (file.size > (type === 'image' ? 10 : 20) * 1024 * 1024) { errors.push(`${file.name}: ${type === 'image' ? '10' : '20'} MB maximum.`); continue; }
      if (assets.reduce((sum, a) => sum + a.size, 0) + file.size > 40 * 1024 * 1024) { errors.push('Keep all attached assets under 40 MB.'); continue; }
      const data = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
        reader.readAsDataURL(new Blob([file], { type: mime }));
      });
      assets.push({ name: file.name, size: file.size, type, role: 'reference', data, preview: URL.createObjectURL(file) });
    }
  } catch (error) { errors.push(error.message); }
  finally {
    readingAssets = false;
    $('asset-drop').classList.remove('reading');
    $('generate').disabled = busy;
    $('asset-files').value = '';
    renderAssets();
    showError('asset-error', errors.join(' '));
    $('live-status').textContent = `${assets.length} assets attached.`;
  }
}
$('asset-files').addEventListener('change', () => addAssets([...$('asset-files').files]));
let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if ([...event.dataTransfer.types].includes('Files')) { event.preventDefault(); dragDepth++; $('asset-drop').classList.add('dragging'); }
});
document.addEventListener('dragover', event => { if ([...event.dataTransfer.types].includes('Files')) { event.preventDefault(); event.dataTransfer.dropEffect = 'copy'; } });
document.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('asset-drop').classList.remove('dragging'); });
document.addEventListener('drop', event => {
  if (event.dataTransfer.files.length) { event.preventDefault(); dragDepth = 0; $('asset-drop').classList.remove('dragging'); addAssets([...event.dataTransfer.files]); }
});
document.addEventListener('paste', event => {
  const files = [...event.clipboardData.files];
  if (files.length) { event.preventDefault(); addAssets(files); }
});
$('generate-form').addEventListener('input', updateForm);
$('generate-form').addEventListener('change', updateForm);
$('duration-minus').addEventListener('click', () => { $('duration').stepDown(); updateForm(); });
$('duration-plus').addEventListener('click', () => { $('duration').stepUp(); updateForm(); });
$('reset-settings').addEventListener('click', () => { applySettings({ ...defaults, prompt: $('prompt').value }); });
$('connection').addEventListener('click', checkConnection);
$('refresh-videos').addEventListener('click', async () => {
  $('refresh-videos').disabled = true;
  await loadHistory();
  await pollVideos();
  $('refresh-videos').disabled = false;
});
$('generate-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (busy || readingAssets) return;
  showError('form-error', '');
  if (!$('prompt').value.trim()) { showError('form-error', 'Describe the video you want to create.'); $('prompt').focus(); return; }
  if ($('prompt').value.trim().length > 2500) { updateForm(); $('prompt').focus(); return; }
  let extra;
  try {
    extra = JSON.parse($('extra').value || '{}');
    if (!extra || typeof extra !== 'object' || Array.isArray(extra)) throw new Error();
  } catch { showError('form-error', 'Additional API parameters must be a JSON object, such as {}.'); $('extra').closest('details').open = true; $('extra').focus(); return; }
  const imageUrl = $('image-url').value.trim();
  if (imageUrl && !imageUrl.startsWith('https://')) { showError('asset-error', 'Use an HTTPS image URL.'); $('image-url').closest('details').open = true; $('image-url').focus(); return; }
  busy = true;
  $('generate').disabled = true;
  $('generate-label').textContent = 'Submitting…';
  $('generate-form').setAttribute('aria-busy', 'true');
  try {
    const video = await api('/api/videos', { method: 'POST', body: JSON.stringify({ ...settings(), extra, assets: assets.map(({ preview, size, ...asset }) => asset), image: imageUrl || undefined }) });
    videos.unshift(video);
    renderVideos();
    schedulePoll();
    $('live-status').textContent = 'Video submitted. The relay is generating it.';
    if (matchMedia('(max-width: 760px)').matches) $('results-heading').scrollIntoView({ behavior: 'instant', block: 'start' });
  } catch (error) { showError('form-error', error.message); }
  finally {
    busy = false;
    $('generate').disabled = false;
    $('generate-label').textContent = 'Generate video';
    $('generate-form').removeAttribute('aria-busy');
  }
});
document.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); $('generate-form').requestSubmit(); }
});
document.addEventListener('visibilitychange', () => { if (!document.hidden) pollVideos(); });
window.addEventListener('pagehide', () => { clearTimeout(timer); assets.forEach(a => URL.revokeObjectURL(a.preview)); });

try { applySettings(JSON.parse(localStorage.getItem(storageKey) || '{}')); } catch { applySettings(defaults); }
await Promise.all([checkConnection(), loadHistory()]);
schedulePoll();
