# Seedance on localhost

Start with `npm start`, then open http://localhost:3000. Node.js 22 or newer is required.

The local `.env` contains your relay endpoint and API key. The server binds to `127.0.0.1`, keeps the key out of browser code, and only exposes the public app files. `.env` and generation history are excluded from Git.

The model is fixed to **seedance-2.5-turbo**. The form includes duration (2–30 seconds), resolution, aspect ratio, audio, fixed camera, seed, negative prompt, reference assets or HTTPS image URL, and additional JSON parameters. Drop assets anywhere on the page, choose multiple files, or paste a clipboard image. Images have reference, first-frame, and last-frame roles. Attached video and audio get reference roles. Limits: 15 files, 10 MB per image, 20 MB per video/audio, 40 MB total. Assets use typed image_url/video_url/audio_url content entries with provider metadata; the first image is also sent through the relay's standard image field. Settings and the prompt survive browser reloads; video task IDs and results survive server restarts in `data/videos.json`. Reattach files after reloading.

Requests use the relay's OpenAI-compatible video routes: `POST /v1/videos`, `GET /v1/videos/:id`, and `GET /v1/videos/:id/content`. Settings are sent as common video fields and provider metadata. The relay decides which settings and image inputs the selected model accepts; unsupported choices produce its actual error. There is no automatic retry of video creation, which avoids duplicate paid submissions.

Prompts allow up to 2,500 characters, matching the relay's validation. Click **Generate video** or press Ctrl/Cmd+Enter. Status is checked every 5 seconds while the page is visible and every 20 seconds while hidden. When ready, play or download the video. Reuse copies the original prompt and settings to the form; reattach a reference image if needed.

Change `PORT` in `.env` if port 3000 is busy. Run `npm test` to verify the proxy against a local fake relay without generating paid videos.
